<?php

$KullaniciA=$_POST['k'];
$parola=$_POST['p'];
if ( $parola == "" || $KullaniciA == "")
{
    header("location:giris.php?k=BosAlan");
    exit();
}
else if(!filter_var($KullaniciA, FILTER_VALIDATE_EMAIL))
{
    header("location:giris.php?k=hatalimail");
    exit();
}
else if ($KullaniciA=="b181210082@sakarya.edu.tr" && $parola=="123")
{
    
    header("location:giris.php?k=$KullaniciA");
    exit();
}
else
{
    header("location:giris.php?k=yanlis");
  
    exit();
}


?>