function EmailDogrulama(inputText)
{
var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
if(inputText.value.match(mailformat))
{
alert("Mesajınız Başarıyla Alındı");
document.form1.mail.focus();
return true;
}
else
{
alert("Geçerli bir Email adresi giriniz!");
document.form1.mail.focus();
return false;
}
}