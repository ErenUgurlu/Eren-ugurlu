<html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/giris.css">
    <link href="https://fonts.googleapis.com/css2?family=Gloria+Hallelujah&family=Indie+Flower&display=swap" rel="stylesheet">

</head>
<body background="img/arkaplan.jpg">
    <div class="wrapper">
        <header>
            <div class="container">
                <div>
                    <span><img src="img/logo.png" class="logo" align = "right" width="75" height="75" /></span>
                </div>
                <nav>
                    <ul>
                        <li><a href="main.html">Anasayfa</a></li>
                        <li><a href="giris.php">Giriş</a></li>
                        <li><a href="ozgecmis.html">Özgeçmiş</a></li>
                        <li><a href="sehrim.html">Şehrim</a></li>
                        <li><a href="iletisim.html">Iletişim</a></li>
                    </ul>
                    <div class="clear"></div>
                </nav>

            </div>
        
        </header>
        <div class="container">
        <form action ="dogrulama.php" method="POST">
            <table background="img/tablo.jpg" width="400" height="400">
                <tr>
                <th><img src="img/girisprofil.png" id="profil" width="75" height="75" /><th>
                </tr>   
                <tr>
                    <th>Log in</th>
                </tr>
                <tr>
                    <td>
                        <?php
                            if(isset($_GET['k']))
                            {
                                $kullanici = $_GET['k'];
                                $fullUrl = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
                                if(strpos($fullUrl,"BosAlan")== true)
                                {
                                    echo "<p>Kullanıcı Adı veya Parola Bos gecmez</p>";
                                    
                                }
                                else if(strpos($fullUrl,"yanlis")== true)
                                {
                                    echo "<p>Kullanıcı Adı veya Parola Yanlış </p>";
                                }
                                else if (strpos($fullUrl,"hatalimail")== true)
                                {
                                    echo "<p>Gecerli bir mail adresi girin</p>";
                                }
                                
                                elseif(strpos($fullUrl,$kullanici)== true)
                                {
                                    
                                    echo "<p style='color:green;'>Giris Basarili\n<p>";
                                    echo "<p style='color:green;'>Hosgeldin</p>";
                                    echo "<p style='color:green;'>$kullanici</p>";
                                    
                                }
                                
            
                            }
        
                        ?>
                    </td>
                </tr>
                <tr>
                    <td><input type="text" value="" placeholder="Kulanıcı Adı" name="k"/></td>
                </tr>
                <tr>
                    <td><input type="password" value="" placeholder="parola" name="p"/></td>
                </tr>
                <tr>
                    <td><input  type="submit" value="Giriş Yap" /></td>
                </tr>
            </table>  
        </form>
        </div>
        <footer>
            <div class="footerContainer">
                <div class="altSatir">
                <a href="https://github.com/ErenUgurlu" target="_blank"><img src="img/github.png" height="25" width="25"><p>github.com/ErenUgurlu</p></a>
                </div>
                <div class="altSatir">
                    <a href="https://www.linkedin.com/in/eren-u%C4%9Furlu-a601941a8/" target="_blank"><img src="img/linkedin.png" height="25" width="25"><p>www.linkedin.com/in/eren-uğurlu</p></a>
                </div>
                <div class="altSatir">
                    <a href="https://www.instagram.com/ugurlueren/" target="_blank"><img src="img/instagram.png" height="30" width="30"><p>www.instagram.com/ugurlueren/</p></a>
                </div>
                
            </div>
            <div style="clear:left;" ></div>
        </footer>     
    </div>
</body>
</html>